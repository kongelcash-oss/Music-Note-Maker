# Music Note Maker Android Project

Native Android WebView wrapper for the Music Note Maker prototype.

- MP3/WAV/MP4 file selection and audio playback (MP4 audio playback depends on device codec support).
- Editable numbered notation 1-4 with low/mid/high dot placement.
- Song title, composer and singer fields.
- A4 print-to-PDF through Android Print Framework.

Important: automatic full-song pitch transcription is not implemented; notes are entered manually.

Build: `./gradlew assembleDebug`
